import UIKit

class KeyboardViewController: UIInputViewController {
    private enum Lang { case ar, en }
    private enum BoardPage { case alpha, sym, sym2 }

    private var currentLang: Lang = .ar
    private var currentPage: BoardPage = .alpha
    private var isShiftOn: Bool = false
    private var isCapsLock: Bool = false
    private var lastShiftTap: TimeInterval = 0

    private let mainStack = UIStackView()
    private let suggestionBar = UIScrollView()
    private let suggestionStack = UIStackView()
    private let rowsStack = UIStackView()
    private var learnedWords: [String: Int] = [:]

    private let arLexicon: [String] = [
        "السلام", "عليكم", "ورحمة", "الله", "وبركاته", "صباح", "الخير", "مساء", "النور",
        "الحمد", "لله", "إن", "شاء", "ما", "تبارك", "جزاك", "خيراً", "شكراً", "لك",
        "أهلاً", "وسهلاً", "كيف", "حالك", "وش", "أخبارك", "يعطيك", "العافية", "تمام",
        "أبشر", "طيب", "الحين", "اليوم", "بكرة", "أمس", "سليس", "كيبورد", "تطبيق",
        "جوال", "الرياض", "جدة", "المدينة", "مكة", "السعودية", "اللهم", "صل", "وسلم",
        "على", "نبينا", "محمد", "حبيبي", "غالي", "ممتاز", "رائع", "جميل", "أكيد", "ممكن"
    ]

    private let enLexicon: [String] = [
        "the", "and", "that", "have", "for", "not", "with", "you", "this", "but",
        "hello", "thanks", "thank", "good", "morning", "evening", "please", "welcome",
        "awesome", "great", "keyboard", "salees", "iphone", "application", "message"
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        loadLearnedWords()
        setupLayout()
        rebuildKeyboard()
    }

    private func setupLayout() {
        view.backgroundColor = UIColor(red: 0.91, green: 0.89, blue: 0.86, alpha: 1.0)

        mainStack.axis = .vertical
        mainStack.spacing = 6
        mainStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mainStack)

        NSLayoutConstraint.activate([
            mainStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 6),
            mainStack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -6),
            mainStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 4),
            mainStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -4),
            view.heightAnchor.constraint(greaterThanOrEqualToConstant: 268)
        ])

        suggestionBar.showsHorizontalScrollIndicator = false
        suggestionBar.heightAnchor.constraint(equalToConstant: 38).isActive = true
        suggestionStack.axis = .horizontal
        suggestionStack.spacing = 8
        suggestionStack.translatesAutoresizingMaskIntoConstraints = false
        suggestionBar.addSubview(suggestionStack)

        NSLayoutConstraint.activate([
            suggestionStack.topAnchor.constraint(equalTo: suggestionBar.topAnchor),
            suggestionStack.bottomAnchor.constraint(equalTo: suggestionBar.bottomAnchor),
            suggestionStack.leadingAnchor.constraint(equalTo: suggestionBar.leadingAnchor, constant: 6),
            suggestionStack.trailingAnchor.constraint(equalTo: suggestionBar.trailingAnchor, constant: -6),
            suggestionStack.heightAnchor.constraint(equalTo: suggestionBar.heightAnchor)
        ])

        rowsStack.axis = .vertical
        rowsStack.spacing = 7
        rowsStack.distribution = .fillEqually

        mainStack.addArrangedSubview(suggestionBar)
        mainStack.addArrangedSubview(rowsStack)
    }

    private func rebuildKeyboard() {
        rowsStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let rows = currentRows()
        for row in rows {
            let rowStack = UIStackView()
            rowStack.axis = .horizontal
            rowStack.spacing = 5
            rowStack.distribution = .fillProportionally
            rowStack.heightAnchor.constraint(equalToConstant: 42).isActive = true

            for key in row {
                let btn = makeKeyButton(for: key)
                rowStack.addArrangedSubview(btn)
            }
            rowsStack.addArrangedSubview(rowStack)
        }
        updateSuggestions()
    }

    private func currentRows() -> [[String]] {
        let digits = ["1","2","3","4","5","6","7","8","9","0"]
        if currentPage == .sym {
            return [
                digits,
                ["-","/",":","؛","(",")","«","»","@","\""],
                ["#+=","،","؟","!","'","…","⌫"],
                [currentLang == .ar ? "أبج" : "ABC", "🌐", "space", ".", "⏎"]
            ]
        }
        if currentPage == .sym2 {
            return [
                ["[","]","{","}","#","%","^","*","+","="],
                ["_","\\","|","~","<",">","€","£","¥","•"],
                ["123",".",",","?","!","'","٪","⌫"],
                [currentLang == .ar ? "أبج" : "ABC", "🌐", "space", ".", "⏎"]
            ]
        }
        if currentLang == .en {
            let r1 = ["q","w","e","r","t","y","u","i","o","p"]
            let r2 = ["a","s","d","f","g","h","j","k","l"]
            let r3 = ["⇧","z","x","c","v","b","n","m","⌫"]
            let shaped = { (arr: [String]) -> [String] in
                arr.map { ($0.count == 1 && (self.isShiftOn || self.isCapsLock)) ? $0.uppercased() : $0 }
            }
            return [
                digits,
                shaped(r1),
                shaped(r2),
                shaped(r3),
                ["123", "🌐", "space", ".", "⏎"]
            ]
        }
        return [
            digits,
            ["ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"],
            ["ش","س","ي","ب","ل","ا","ت","ن","م","ك","ة"],
            ["ء","ظ","ط","ذ","د","ز","ر","و","ى","⌫"],
            ["١٢٣", "🌐", "space", ".", "⏎"]
        ]
    }

    private func makeKeyButton(for label: String) -> UIButton {
        let btn = UIButton(type: .system)
        let isSpecial = ["⌫","⇧","123","١٢٣","أبج","ABC","#+=","🌐","⏎"].contains(label)
        let displayTitle: String
        if label == "space" {
            displayTitle = currentLang == .ar ? "‹  عربي  ›" : "‹  English  ›"
        } else {
            displayTitle = label
        }
        btn.setTitle(displayTitle, for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: label == "space" ? 15 : 18, weight: isSpecial ? .semibold : .regular)
        btn.setTitleColor(UIColor(red: 0.12, green: 0.11, blue: 0.10, alpha: 1.0), for: .normal)
        btn.backgroundColor = isSpecial
            ? UIColor(red: 0.84, green: 0.81, blue: 0.77, alpha: 1.0)
            : UIColor(red: 0.99, green: 0.98, blue: 0.96, alpha: 1.0)
        btn.layer.cornerRadius = 8
        btn.layer.shadowColor = UIColor.black.cgColor
        btn.layer.shadowOpacity = 0.12
        btn.layer.shadowOffset = CGSize(width: 0, height: 1)
        btn.layer.shadowRadius = 0.5
        btn.accessibilityIdentifier = label
        btn.addTarget(self, action: #selector(onKeyTap(_:)), for: .touchUpInside)

        if label == "space" {
            let pan = UIPanGestureRecognizer(target: self, action: #selector(onSpaceSwipe(_:)))
            btn.addGestureRecognizer(pan)
            btn.widthAnchor.constraint(greaterThanOrEqualToConstant: 145).isActive = true
        }
        return btn
    }

    @objc private func onSpaceSwipe(_ gesture: UIPanGestureRecognizer) {
        if gesture.state == .ended {
            let tx = gesture.translation(in: view).x
            if abs(tx) > 28 {
                currentLang = (currentLang == .ar) ? .en : .ar
                currentPage = .alpha
                rebuildKeyboard()
            }
        }
    }

    @objc private func onKeyTap(_ sender: UIButton) {
        guard let key = sender.accessibilityIdentifier else { return }
        let proxy = textDocumentProxy

        switch key {
        case "⌫":
            proxy.deleteBackward()
        case "space":
            commitCurrentWord()
            proxy.insertText(" ")
        case "⏎":
            commitCurrentWord()
            proxy.insertText("\n")
        case "🌐":
            currentLang = (currentLang == .ar) ? .en : .ar
            currentPage = .alpha
            rebuildKeyboard()
            return
        case "⇧":
            let now = Date().timeIntervalSince1970
            if isCapsLock {
                isCapsLock = false
                isShiftOn = false
            } else if isShiftOn && (now - lastShiftTap < 0.35) {
                isCapsLock = true
            } else {
                isShiftOn.toggle()
            }
            lastShiftTap = now
            rebuildKeyboard()
            return
        case "123", "١٢٣":
            currentPage = .sym
            rebuildKeyboard()
            return
        case "أبج", "ABC":
            currentPage = .alpha
            rebuildKeyboard()
            return
        case "#+=":
            currentPage = .sym2
            rebuildKeyboard()
            return
        default:
            proxy.insertText(key)
            if isShiftOn && !isCapsLock {
                isShiftOn = false
                rebuildKeyboard()
                return
            }
        }
        updateSuggestions()
    }

    private func currentPrefix() -> String {
        let before = textDocumentProxy.documentContextBeforeInput ?? ""
        let parts = before.components(separatedBy: CharacterSet.whitespacesAndNewlines)
        return parts.last ?? ""
    }

    private func commitCurrentWord() {
        let word = currentPrefix().trimmingCharacters(in: .punctuationCharacters)
        guard word.count >= 2 else { return }
        learnedWords[word, default: 0] += 1
        UserDefaults.standard.set(learnedWords, forKey: "salees.learned")
    }

    private func loadLearnedWords() {
        if let saved = UserDefaults.standard.dictionary(forKey: "salees.learned") as? [String: Int] {
            learnedWords = saved
        }
    }

    private func updateSuggestions() {
        suggestionStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let prefix = currentPrefix()

        if let clip = UIPasteboard.general.string?.trimmingCharacters(in: .whitespacesAndNewlines), !clip.isEmpty {
            let clipBtn = UIButton(type: .system)
            let preview = clip.count > 20 ? String(clip.prefix(20)) + "…" : clip
            clipBtn.setTitle(currentLang == .ar ? "لصق: \(preview)" : "Paste: \(preview)", for: .normal)
            clipBtn.setTitleColor(.white, for: .normal)
            clipBtn.backgroundColor = UIColor(red: 0.14, green: 0.42, blue: 0.35, alpha: 1.0)
            clipBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
            clipBtn.contentEdgeInsets = UIEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
            clipBtn.layer.cornerRadius = 8
            clipBtn.addAction(UIAction { [weak self] _ in
                self?.textDocumentProxy.insertText(clip)
            }, for: .touchUpInside)
            suggestionStack.addArrangedSubview(clipBtn)
        }

        let pool = (currentLang == .ar) ? arLexicon : enLexicon
        let personal = learnedWords
            .filter { $0.value >= 2 && (prefix.isEmpty || $0.key.hasPrefix(prefix)) }
            .sorted { $0.value > $1.value }
            .map { $0.key }

        let dictMatches = prefix.isEmpty ? Array(pool.prefix(5)) : pool.filter { $0.hasPrefix(prefix) }
        var combined: [String] = []
        for w in (personal + dictMatches) {
            if !combined.contains(w) { combined.append(w) }
            if combined.count >= 6 { break }
        }

        for word in combined {
            let btn = UIButton(type: .system)
            btn.setTitle(word, for: .normal)
            btn.setTitleColor(UIColor(red: 0.12, green: 0.11, blue: 0.10, alpha: 1.0), for: .normal)
            btn.backgroundColor = UIColor(red: 0.95, green: 0.94, blue: 0.91, alpha: 1.0)
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .medium)
            btn.contentEdgeInsets = UIEdgeInsets(top: 4, left: 12, bottom: 4, right: 12)
            btn.layer.cornerRadius = 8
            btn.addAction(UIAction { [weak self] _ in
                guard let self = self else { return }
                let current = self.currentPrefix()
                for _ in 0..<current.count {
                    self.textDocumentProxy.deleteBackward()
                }
                self.textDocumentProxy.insertText(word + " ")
                self.learnedWords[word, default: 0] += 1
                self.updateSuggestions()
            }, for: .touchUpInside)
            suggestionStack.addArrangedSubview(btn)
        }
    }
}
