import type { LearnedWord } from "./predict";
import type { Lang } from "./text";

const STORE_KEY = "salees.store.v1";

export type StoreData = {
  learned: LearnedWord[];
  draft: string;
  lang: Lang;
};

export function loadStore(): StoreData {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return { learned: [], draft: "", lang: "ar" };
    const parsed = JSON.parse(raw);
    return {
      learned: Array.isArray(parsed.learned) ? parsed.learned : [],
      draft: typeof parsed.draft === "string" ? parsed.draft : "",
      lang: parsed.lang === "en" ? "en" : "ar",
    };
  } catch {
    return { learned: [], draft: "", lang: "ar" };
  }
}

export function saveStore(data: StoreData): void {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(data));
  } catch {
    /* ignore */
  }
}
