import { normalize, type Lang } from "./text";

const AR_WORDS = [
  "السلام", "عليكم", "ورحمة", "الله", "وبركاته", "صباح", "الخير", "مساء", "النور",
  "الحمد", "لله", "إن", "شاء", "ما", "تبارك", "جزاك", "خيراً", "شكراً", "لك",
  "أهلاً", "وسهلاً", "كيف", "حالك", "أخبارك", "يعطيك", "العافية", "تمام", "طيب",
  "أبشر", "الحين", "اليوم", "بكرة", "أمس", "بعد", "قبل", "عند", "مع", "من", "إلى",
  "على", "في", "هذا", "هذه", "الذي", "التي", "كان", "كانت", "يكون", "تكون",
  "سليس", "كيبورد", "لوحة", "مفاتيح", "تطبيق", "برنامج", "جوال", "آيفون", "ملف",
  "تحميل", "تثبيت", "الرياض", "جدة", "مكة", "المدينة", "الدمام", "السعودية",
  "اللهم", "صل", "وسلم", "نبينا", "محمد", "حبيبي", "غالي", "ممتاز", "رائع", "جميل",
  "أكيد", "ممكن", "طبعاً", "والله", "يلا", "خلاص", "شوي", "كثير", "جداً", "مرة",
  "عشان", "ليش", "وين", "متى", "مين", "وش", "ايش", "كذا", "هنا", "هناك",
  "أول", "ثاني", "آخر", "كل", "بعض", "غير", "بدون", "حتى", "لو", "إذا",
  "أريد", "أبغى", "أبي", "أقدر", "تقدر", "نقدر", "يسوي", "أسوي", "تسوي", "سويت",
  "كتابة", "رسالة", "كلمة", "كلمات", "حرف", "حروف", "نسخ", "لصق", "حفظ", "مسح"
];

const EN_WORDS = [
  "the", "be", "to", "of", "and", "a", "in", "that", "have", "it",
  "for", "not", "on", "with", "he", "as", "you", "do", "at", "this",
  "but", "his", "by", "from", "they", "we", "say", "her", "she", "or",
  "an", "will", "my", "one", "all", "would", "there", "their", "what", "so",
  "up", "out", "if", "about", "who", "get", "which", "go", "me", "when",
  "make", "can", "like", "time", "no", "just", "him", "know", "take", "people",
  "into", "year", "your", "good", "some", "could", "them", "see", "other", "than",
  "then", "now", "look", "only", "come", "its", "over", "think", "also", "back",
  "after", "use", "two", "how", "our", "work", "first", "well", "way", "even",
  "new", "want", "because", "any", "these", "give", "day", "most", "us", "hello",
  "thanks", "thank", "please", "welcome", "awesome", "great", "keyboard", "salees",
  "iphone", "apple", "application", "message", "morning", "evening", "night", "today"
];

export function wordsByFirst(lang: Lang, firstChar: string): string[] {
  const pool = lang === "ar" ? AR_WORDS : EN_WORDS;
  const nf = normalize(firstChar, lang);
  return pool.filter((w) => normalize(w, lang).startsWith(nf));
}
