export type Lang = "ar" | "en";

export function normalize(word: string, lang: Lang): string {
  const clean = word.trim().toLowerCase();
  if (lang === "ar") {
    return clean
      .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
      .replace(/[أإآٱ]/g, "ا")
      .replace(/ة/g, "ه")
      .replace(/ى/g, "ي")
      .replace(/[ؤئ]/g, "ء");
  }
  return clean;
}

export function collapseRepeats(str: string): string {
  let out = "";
  for (const ch of str) {
    if (out[out.length - 1] !== ch) out += ch;
  }
  return out;
}

export function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i]![0] = i;
  for (let j = 0; j <= n; j++) dp[0]![j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i]![j] = Math.min(
        dp[i - 1]![j]! + 1,
        dp[i]![j - 1]! + 1,
        dp[i - 1]![j - 1]! + cost
      );
    }
  }
  return dp[m]![n]!;
}

export function isBoundary(ch: string): boolean {
  return !/^[\p{L}\p{N}']$/u.test(ch);
}

export function currentToken(text: string, caret: number): { word: string; start: number; end: number } {
  let start = caret;
  while (start > 0 && !isBoundary(text[start - 1] ?? "")) start--;
  let end = caret;
  while (end < text.length && !isBoundary(text[end] ?? "")) end++;
  return { word: text.slice(start, caret), start, end };
}

export function replaceRange(text: string, start: number, end: number, chunk: string): { text: string; caret: number } {
  const next = text.slice(0, start) + chunk + text.slice(end);
  return { text: next, caret: start + chunk.length };
}

export function detectLang(word: string): Lang {
  return /[\u0600-\u06FF]/.test(word) ? "ar" : "en";
}

export function formatCount(n: number, lang: Lang): string {
  if (lang === "ar") {
    return n.toLocaleString("ar-EG");
  }
  return String(n);
}
